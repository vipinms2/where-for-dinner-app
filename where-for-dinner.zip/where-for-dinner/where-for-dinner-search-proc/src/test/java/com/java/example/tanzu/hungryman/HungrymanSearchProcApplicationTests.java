package com.java.example.tanzu.hungryman;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HungrymanSearchProcApplicationTests {

	@Test
	void contextLoads() {
	}

}
