# where-for-dinner-search-proc
Where for Dinner search processor service.
