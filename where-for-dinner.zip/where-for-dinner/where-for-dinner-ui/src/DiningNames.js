function DiningName(props)
{
    return(
        <div>
            <label>Dining Name:</label>
            <input placeholder="Restaurant Name" type="text"></input>
            <button>=&gt;</button>
        </div>
    );
}

export default DiningName;