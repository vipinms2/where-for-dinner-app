package com.java.example.tanzu.hungryman;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HungrymanNotifyApplication {

	public static void main(String[] args) {
		SpringApplication.run(HungrymanNotifyApplication.class, args);
	}

}
