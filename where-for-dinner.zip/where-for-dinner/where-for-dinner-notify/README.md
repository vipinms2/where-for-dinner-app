# where-for-dinner-notify
Where for Dinner optional external notification producer.
