package com.java.example.tanzu.hungryman;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@ActiveProfiles("local")
@SpringBootTest
class HungrymanAvailabilityApplicationTests {

	@Test
	void contextLoads() {
	}

}
